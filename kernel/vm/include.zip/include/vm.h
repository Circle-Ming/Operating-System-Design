#ifndef  _ZJUNIX_VM_H
#define  _ZJUNIX_VM_H

#include <zjunix/page.h>

#define  USER_CODE_ENTRY
#define  USER_DATA_ENTRY
#define  USER_DATA_END
#define  USER_BRK_ENTRY     0x10000000
#define  USER_STACK_ENTRY   0x80000000
#define  USER_DEFAULT_ATTR     0x0f

// extern struct page;

struct mm_struct; 

struct vma_struct {
    struct mm_struct *vm_mm;
    unsigned long vm_start, vm_end;
    struct vma_struct *vm_next;
    unsigned int cnt;
};

struct mm_struct {
    struct vma_struct *mmap;
    struct vma_struct *mmap_cache;

    int map_count;
    // unsigned int free_area_cache;
    pgd_t *pgd;

    unsigned int start_code, end_code;
    unsigned int start_data, end_data;
    unsigned int start_brk, brk;
    unsigned int start_stack;
};

void mm_delete(struct mm_struct* mm);
struct mm_struct* mm_create();

unsigned long do_map(unsigned long addr, unsigned long len, unsigned long flags);
int do_unmap(unsigned long addr, unsigned long len);
int is_in_vma(unsigned long addr);
#endif
